package BookMap.PentaRim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PentaRimApplicationTests {

	@Test
	void contextLoads() {
	}

}
